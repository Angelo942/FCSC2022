/* SPDX-License-Identifier: GPL-2.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 2 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <https://www.gnu.org/licenses/>.
 */
#include "base64.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <assert.h>

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Woverride-init"
static const char LUT[0x100] = {
	[0x00 ... 0xFF] = -1,

	['A'] =  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15,
		16, 17, 18, 19, 20, 21, 22, 23, 24, 25,

	['a'] = 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41,
		42, 43, 44, 45, 46, 47, 48, 49, 50, 51,

	['0'] = 52, 53, 54, 55, 56, 57, 58, 59, 60, 61,

	['+'] = 62,
	['/'] = 63,
	/*['='] = 0,*/
};
#pragma GCC diagnostic pop

bool b64_decode(const char *in, size_t size, char *out)
{
	/* Make sure the size is round */
	if(size % 4)
		return false;

	while(0 != size) {
		/* Copy a block */
		unsigned char block[4];
		memcpy(block, in, sizeof(block));

		/* Chop padding */
		size_t n = 3, m = 4;

		if(block[3] == '=') {
			n--;
			m--;
		}

		if(block[2] == '=') {
			n--;
			m--;
		}

		/* Make sure every chars are valid */
		unsigned int num = 0;
		for(size_t i = 0; i < m; i++) {
			const char c = LUT[block[i]];

			if(-1 == c)
				return false;

			num = (num << 6) | c;
		}
		num <<= 6 * (4 - m);

		/* Write block output */
		for(size_t i = 0; i < n; i++) {
			char c = num >> (8 * (2 - i));
			*out++ = c;
		}

		/* Next block */
		in   += 4;
		size -= 4;
	}

	return true;
}

#ifndef NDEBUG
__attribute__((constructor))
static void b64_test()
{
	char buf[4] = "AAAA";

	/* B */
	assert(true == b64_decode("Qg==", 4, buf));
	assert(0    == memcmp(buf, "BAAA", 4));

	/* CC */
	assert(true == b64_decode("Q0M=", 4, buf));
	assert(0    == memcmp(buf, "CCAA", 4));

	/* DDD */
	assert(true == b64_decode("RERE", 4, buf));
	assert(0    == memcmp(buf, "DDDA", 4));

	/* A bit tricky ! EE */
	assert(true == b64_decode("RQ==RQ==", 8, buf));
	assert(0    == memcmp(buf, "EEDA", 4));

	/* All tests passed ! */
}
#endif
