/* SPDX-License-Identifier: GPL-2.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 2 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <https://www.gnu.org/licenses/>.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdnoreturn.h>
#include <string.h>

#include <unistd.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <sys/syscall.h>

#include <sys/prctl.h>
#include <linux/prctl.h>
#include <linux/seccomp.h>
#include <linux/filter.h>

#include "debug.h"
#include "worker.h"
#include "audit.h"

/* Docker already sets a seccomp filter. We cannot enable strict mode */
#define SANDBOX_STRICT 0

static inline void hexdump(void *data, size_t n)
{
	for(size_t i = 0; i < n; i++) {
		fprintf(stderr, "%02X", ((unsigned char*)data)[i]);
		fputc(0x0F == (i & 0x0F) ? '\n' : ' ', stderr);
	}

	if(n & 0x0F)
		fputc('\n', stderr);
}

/* top 10 syscall betrayal */
noreturn void _exit(int status)
{
	syscall(SYS_exit, status);
	_exit(status);
}

int seccomp(unsigned int operation, unsigned int flags, void *args)
{
	return syscall(SYS_seccomp, operation, flags, args);
}

noreturn void sandbox(struct shared *shared)
{
	/* Make sure we die if parent dies */
	if(0 != prctl(PR_SET_PDEATHSIG, SIGKILL, 0, 0, 0)) {
		perror("prctl PR_SET_PDEATHSIG");
		exit(EXIT_FAILURE);
	}

	/* Enable seccomp */
#if SANDBOX_STRICT == 1
	if(0 != seccomp(SECCOMP_SET_MODE_STRICT, 0, NULL)) {
	 	perror("seccomp");
	 	exit(EXIT_FAILURE);
	}
#else
	static struct sock_filter filter[] = {
		#include "filter.i"
	};

	static struct sock_fprog bpf = {
		.filter = filter,
		.len    = sizeof(filter) / sizeof(*filter),
	};

	if(0 != prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)) {
		perror("prctl PR_SET_NO_NEWPRIVS");
		exit(EXIT_FAILURE);
	}

	if(0 != seccomp(SECCOMP_SET_MODE_FILTER, 0, &bpf)) {
	 	perror("seccomp");
	 	exit(EXIT_FAILURE);
	}
#endif

	/* From now on we cannot use exit anymore, only _exit */
	do {
		/* We need to log something*/
		if(worker(shared))
			break;
	} while(shared->keepalive);

	_exit(EXIT_SUCCESS);
}

static int request(struct shared *shared)
{
	pid_t pid = fork();

	if(0 > pid) {
		perror("fork");
		exit(EXIT_FAILURE);
	}

	if(0 == pid) {
		sandbox(shared);
		_exit(EXIT_FAILURE);
	}

	int status;
	if(pid != waitpid(pid, &status, 0)) {
		perror("waitpid");
		exit(EXIT_FAILURE);
	}

	return status;
}

int main(void)
{
	/* Prepare malloc arena
	 *
	 * Since every workers are sandboxed with seccomp, we cannot use the
	 * getrandom(2) syscall.
	 *
	 * malloc calls ptmalloc_init, tcache_key_initialize, and then
	 * __getrandom.
	 *
	 * This means that any function that allocates memory dynamically will
	 * get a SIGKILL in the sandbox... unless the tcache key is *already*
	 * generated. This is what this call does.
	 */
	free(malloc(0));

	setbuf(stdin,  NULL);
	setbuf(stdout, NULL);

	/* Prepare shared memory segment */
	struct shared *shared = mmap(NULL, sizeof(*shared),
		PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);

	if(MAP_FAILED == shared) {
		perror("mmap");
		return EXIT_FAILURE;
	}

	/* Main loop */
	do {
		int status = request(shared);
		DEBUG("status = %d\n", status);
		audit(shared, status);
	} while(shared->keepalive);

	return EXIT_SUCCESS;
}
