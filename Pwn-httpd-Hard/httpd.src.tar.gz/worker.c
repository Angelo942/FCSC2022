/* SPDX-License-Identifier: GPL-2.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 2 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <https://www.gnu.org/licenses/>.
 */
#include "worker.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>

#include "debug.h"
#include "http.h"
#include "base64.h"

#define LOGIN    "admin"
#define PASSWORD "admin"

static inline bool shouldKeepAlive(const struct http_request *req)
{
	struct http_header *header = http_findHeader(req, "connection");

	if(NULL == header)
		return false;

	return 0 == strcasecmp(header->value, "keep-alive");
}

static inline char* getAuth(const struct http_request *req)
{
	struct http_header *header = http_findHeader(req, "authorization");

	/* No authorization */
	if(NULL == header)
		return NULL;

	/* Make sure it starts with Basic */
	if(0 != strncasecmp(header->value, "Basic ", 6))
		return NULL;

	char *b64 = header->value + 6;
	while(isspace(*b64))
		b64++;

	return b64;
}

static inline void askAuth(const char *msg)
{
	/* Send message */
	const struct http_header auth = {"WWW-Authenticate", "Basic"};
	http_reply(401, "Unauthorized", &auth, 1, msg, strlen(msg));
}

bool checkAuth(const char *b64, struct shared *shared)
{
	char creds[0x100] = {};

	if(true != b64_decode(b64, strlen(b64), creds)) {
		askAuth("Malformed base64");
		return false;
	}

	DEBUG("creds = %s\n", creds);

	/* Parse creds */
	char *saveptr;
	const char *login    = strtok_r(creds, ":", &saveptr);
	const char *password = strtok_r(NULL,  "",  &saveptr);

	/* Check login */
	if(0 != strcmp(login, LOGIN)) {
		askAuth("Invalid username");
		return false;
	}

	/* Check password */
	if(0 != strcmp(password, PASSWORD)) {
		askAuth("Invalid password");
		return false;
	}

	/* We're all set, keep track of the user */
	strncpy(shared->username, login, sizeof(shared->username));
	shared->loggedin = true;

	return true;
}

/* returns true if request should be audited */
bool worker(struct shared *shared)
{
	/* Reset some values */
	shared->keepalive = false;
	shared->loggedin  = false;

	/* Parse request */
	struct http_request *req = http_recv();

	if(NULL == req)
		return false;

	/* Determine the keep-alive-ness */
	shared->keepalive = shouldKeepAlive(req);

	/* Request must be GET */
	if(0 != strcmp(req->method, "GET")) {
		http_text(HTTP_STATUS_BAD_METHOD, "GET || GTFO");
		return false;
	}

	/* Get b64 of creds */
	const char *b64 = getAuth(req);
	if(NULL == b64) {
		askAuth("PTDR t'es qui ?");
		return false;
	}

	DEBUG("b64 = %s\n", b64);

	/* Check the credentials */
	if(!checkAuth(b64, shared))
		return false;

	/* All that fuss for what ? */
	http_text(HTTP_STATUS_OK, "Congratulations! Now get the flag.");

	return true;
}
