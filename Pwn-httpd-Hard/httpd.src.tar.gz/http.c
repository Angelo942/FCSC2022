/* SPDX-License-Identifier: GPL-2.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 2 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <https://www.gnu.org/licenses/>.
 */
#include "http.h"

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <limits.h>

#include <assert.h>

#include "debug.h"

static const struct {
	int status;
	char *reason;
} status[] = {
	[HTTP_STATUS_OK]           = {200, "OK"},
	[HTTP_STATUS_BAD_REQUEST]  = {400, "Bad request"},
	[HTTP_STATUS_UNAUTHORIZED] = {401, "Unauthorized"},
	[HTTP_STATUS_BAD_METHOD]   = {405, "Method not allowed"},
};

void http_reply(
	int code, const char *text,
	const struct http_header *headers, size_t count,
	const void *body, size_t size)
{
#ifndef NDEBUG
	assert(NULL == strpbrk(text, "\r\n"));

	for(size_t i = 0; i < count; i++) {
		assert(NULL == strpbrk(headers[i].name, "\r\n"));
		assert(NULL == strpbrk(headers[i].value, "\r\n"));
	}
#endif

	/* Status code */
	printf("HTTP/1.1 %d %s\r\n", code, text);

	/* Headers */
	for(size_t i = 0; i < count; i++)
		printf("%s: %s\r\n", headers[i].name, headers[i].value);
	printf("Content-Length: %lu\r\n", size);
	printf("\r\n");

	/* Body */
	fwrite(body, 1, size, stdout);
}

void http_text(enum http_status s, const char *msg)
{
	assert(s < 10);

	const struct http_header headers[] = {
		{"Content-Type", "text/plain"},
	};

	return http_reply(
		status[s].status, status[s].reason,
		headers, sizeof(headers) / sizeof(*headers),
		msg, strlen(msg)
	);
}

static inline void http_400(const char *body)
{
	return http_text(HTTP_STATUS_BAD_REQUEST, body);
}

static struct http_request* http_parse_status(char *line)
{
	char *saveptr;
	const char *method = strtok_r(line, " ", &saveptr);
	const char *path   = strtok_r(NULL, " ", &saveptr);
	const char *proto  = strtok_r(NULL, " ", &saveptr);
	const char *end    = strtok_r(NULL, " ", &saveptr);

	DEBUG("method = %1$p %1$s\n", method);
	DEBUG("path   = %1$p %1$s\n", path);
	DEBUG("proto  = %1$p %1$s\n", proto);
	DEBUG("end    = %1$p %1$s\n", end);

	/* protocol does not contain spaces */
	if(NULL != end) {
		http_400("Invalid status line (too many spaces)");
		return NULL;
	}

	/* proto must be HTTP/1.1 (maybe with \r) */
	if(0 != memcmp(proto, "HTTP/1.1", 8)) {
		http_400("Invalid status line (invalid proto)");
		return NULL;
	}

	/* Note: this accepts HTTP/1.1 \r foo \n, not a big risk */
	if('\r' != proto[8] && 0 != proto[8]) {
		http_400("Invalid status line (strange proto)");
		return NULL;
	}

	struct http_request *ret = malloc(sizeof(*ret));
	ret->method  = strdup(method);
	ret->path    = strdup(path);

	ret->headers = NULL;
	ret->count   = 0;

	ret->body    = NULL;
	ret->size    = 0;

	return ret;
}

static int cmp_hdr(const void *a, const void *b)
{
	const struct http_header *ha = a;
	const struct http_header *hb = b;

	return strcasecmp(ha->name, hb->name);
}

struct http_header* http_findHeader(const struct http_request *req, const char *str)
{
	const struct http_header hdr = {(char*)str, NULL};
	return bsearch(&hdr, req->headers, req->count, sizeof(hdr), cmp_hdr);
}


static char* str_trim(char *str)
{
	/* trim left */
	while(isspace(*str))
		str++;

	/* trim right */
	size_t len = strlen(str);

	while(len > 0 && isspace(str[len - 1]))
		len--;

	str[len] = 0;

	return str;
}

static ssize_t http_parse_headers(struct http_header **headers)
{
	size_t n = 0;
	*headers = malloc(0);

	while(1) {
		char line[0x1000];

		if(NULL == fgets(line, sizeof(line), stdin)) {
			http_400("Unexpected EOF");
			goto err;
		}

		/* Check for end of headers */
		if(0 == strcmp(line, "\r\n") || 0 == strcmp(line, "\n"))
			break;

		/* This is an header ! Push it to the "vector" */
		char *saveptr;
		char *name  = strtok_r(line, ":", &saveptr);
		char *value = strtok_r(NULL, "",  &saveptr);

		DEBUG("- %s\t%s", name, value);

		if(NULL == name || NULL == value) {
			http_400("Malformed header");
			goto err;
		}

		/* trim spaces */
		name  = str_trim(name);
		value = str_trim(value);

		/* Extend the number of headers */
		*headers = realloc(*headers, (n + 1) * sizeof(**headers));
		(*headers)[n].name  = strdup(name);
		(*headers)[n].value = strdup(value);
		n++;

		if(n > LONG_MAX)
			goto err;
	}

	/* Sort the headers (might be slower than bubble sort) */
	qsort(*headers, n, sizeof(**headers), cmp_hdr);

	return n;

err:
	for(size_t i = 0; i < n; i++) {
		free((*headers)[i].name);
		free((*headers)[i].value);
	}

	free(*headers);
	*headers = NULL;

	return -1;
}

static bool http_parse_body(struct http_request *req, size_t len)
{
	req->body = malloc(req->size);

	if(NULL == req->body)
		return false;

	size_t n = 0;
	while(n < len) {
		size_t r = fread(req->body + n, 1, len - n, stdin);

		if(0 == r)
			goto err;

		n += r;
	}

	req->size = len;
	return true;

err:
	req->size = 0;
	free(req->body);

	return false;
}

struct http_request* http_recv()
{
	char line[0x1000] = {};

	/* Read first line */
	if(NULL == fgets(line, sizeof(line), stdin))
		return NULL;

	struct http_request *req = http_parse_status(line);

	/* Parse headers */
	struct http_header *headers;
	ssize_t count = http_parse_headers(&headers);

	if(count < 0)
		goto err;

	req->headers = headers;
	req->count   = count;

#ifndef NDEBUG
	DEBUG("List of headers (%lu)", req->count);

	for(size_t i = 0; i < req->count; i++) {
		const struct http_header *h = &req->headers[i];
		DEBUG("[%s]\t[%s]", h->name, h->value);
	}

	DEBUG("\n");
#endif

	/* Get the value of Content-Length */
	ssize_t clen = 0;
	struct http_header *hdr_clen = http_findHeader(req, "content-length");

	if(NULL != hdr_clen) {
		char *endptr = NULL;
		clen = strtoll(hdr_clen->value, &endptr, 10);

		/* Invalid number */
		if(0 == *(hdr_clen->value) || 0 != *endptr) {
			http_400("Could not parse size");
			goto err_hdr;
		}

		/* Negative size */
		if(clen < 0) {
			http_400("Negative size");
			goto err_hdr;
		}
	}

	/* Body */
	if(true != http_parse_body(req, clen))
		goto err_hdr;

	return req;

err_hdr:
	for(size_t i = 0; i < req->count; i++) {
		free(req->headers[i].name);
		free(req->headers[i].value);
	}

	free(req->headers);

err:
	free(req->method);
	free(req->path);
	free(req);
	
	return NULL;
}
