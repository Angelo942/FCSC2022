/* SPDX-License-Identifier: GPL-2.0-or-later
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 2 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <https://www.gnu.org/licenses/>.
 */
#pragma once
#include <stdlib.h>

struct http_header {
	char *name;
	char *value;
};

struct http_request {
	char *method;
	char *path;

	struct http_header *headers;
	size_t count;

	void *body;
	size_t size;
};

enum http_status {
	HTTP_STATUS_OK,
	HTTP_STATUS_BAD_REQUEST,
	HTTP_STATUS_UNAUTHORIZED,
	HTTP_STATUS_BAD_METHOD,
};

/* Send a well-formatted HTTP/1.1 reply */
void http_reply(
	int code, const char *text,
	const struct http_header *headers, size_t count,
	const void *body, size_t size);

void http_format(
	enum http_status status,
	const struct http_header *headers, size_t count,
	const char *fmt, ...);

void http_text(enum http_status status, const char *msg);

/* Parse a request */
struct http_header*  http_findHeader(const struct http_request *req, const char *str);
struct http_request* http_recv();
